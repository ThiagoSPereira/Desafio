package com.desafio.controler;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.desafio.domain.Opcao;
import com.desafio.domain.Enquete;
import com.desafio.objcustom.EnqueteJson;
import com.desafio.objcustom.RespostCadastro;
import com.desafio.objcustom.Statis;
import com.desafio.service.OpcaoService;
import com.desafio.service.EnqueteService;

@RestController
public class EnqueteControler {

	@Autowired
	EnqueteService service;
	@Autowired
	OpcaoService opService;

	// Buscar um emquete no banco
	@RequestMapping(method = RequestMethod.GET, value = "poll/{id}")
	public ResponseEntity busca(@PathVariable Long id) {
		System.out.println("teste");
		Enquete questao = service.buscar(id);
		if (questao != null) {
			if (questao.getViews() == null) {
				questao.setViews(1L);
			} else {
				questao.setViews(questao.getViews() + 1);
			}
			service.cadastrar(questao);
			questao.setViews(null);
			int id1 = 0;
			for (Opcao op : questao.getOpcoes()) {
				op.setQty(null);
				questao.getOpcoes().set(id1, op);
				id1++;
			}
		} else {

			return ResponseEntity.status(HttpStatus.CREATED).body("404 Not Found");

		}
		return ResponseEntity.status(HttpStatus.CREATED).body(questao);
	}

	// Método Cadastro de Enquete
	@RequestMapping(method = RequestMethod.POST, value = "/poll", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RespostCadastro> criarEnquete(@RequestBody EnqueteJson enquete) {

		System.out.println("cadastrar");
		List<Opcao> opcoes = new ArrayList<>();
		for (String op : enquete.getOptions()) {
			Opcao opcao = new Opcao();
			opcao.setOption_description(op);
			opcao.setQty(0L);
			opcoes.add(opcao);
		}

		Enquete questao = new Enquete();
		questao.setPoll_description(enquete.getPoll_description());
		questao.setOpcoes(opcoes);
		questao.setViews(0L);
		questao = service.cadastrar(questao);

		RespostCadastro pollid = new RespostCadastro();
		pollid.setPoll_id(questao.getPoll_id());
		return new ResponseEntity<RespostCadastro>(pollid, HttpStatus.CREATED);

	}

	// Resgistrar voto em uma enquete
	@RequestMapping(method = RequestMethod.POST, value = "poll/{id}/vote", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity responderEnquete(@PathVariable Long id, @RequestBody Opcao option) {

		Opcao opcao = opService.buscar(option.getOption_id());
		if (service.buscar(id) != null || opcao != null) {
			if (opcao.getQty() == null) {
				opcao.setQty(1L);
			} else {
				opcao.setQty(opcao.getQty() + 1);
			}
		}else{
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body("404 Not Found");
		}
		opService.cadastrar(opcao);

		return ResponseEntity.status(HttpStatus.CREATED).body("");
	}

	
	//Metodo para ver as estatisticas das enquetes
	@RequestMapping(method = RequestMethod.GET, value = "poll/{id}/statis", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Statis> statis(@PathVariable Long id) {
		Statis statis = new Statis();
		Enquete questao = service.buscar(id);
		statis.setViews(questao.getViews());
		List<Opcao> opcoes = new ArrayList<>();
		for (Opcao op : questao.getOpcoes()) {
			op.setPoll(null);
			op.setOption_description(null);
			opcoes.add(op);
		}
		statis.setVotes(opcoes);

		return new ResponseEntity<Statis>(statis, HttpStatus.CREATED);
	}

}
