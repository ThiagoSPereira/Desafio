package com.desafio.objcustom;

import java.util.List;

import com.desafio.domain.Opcao;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class Statis {

	private Long views;
	
	private List<Opcao> votes;

	public Long getViews() {
		return views;
	}

	public void setViews(Long views) {
		this.views = views;
	}

	public List<Opcao> getVotes() {
		return votes;
	}

	public void setVotes(List<Opcao> votes) {
		this.votes = votes;
	}
}
