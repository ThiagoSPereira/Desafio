package com.desafio.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.desafio.domain.Opcao;
import com.desafio.repositorio.OpcaoRepositorio;
import com.desafio.repositorio.EnqueteRepositorio;

@Service
public class OpcaoService {

	
	private OpcaoRepositorio opcaoRepositorio;
	private EnqueteRepositorio questaoRepositorio;
	
	@Autowired
	public OpcaoService(OpcaoRepositorio opcaoRepositorio, EnqueteRepositorio questaoRepositorio){
		this.questaoRepositorio = questaoRepositorio;
		this.opcaoRepositorio = opcaoRepositorio;
	}
	
	public Opcao cadastrar(Opcao opcao){
		
		opcaoRepositorio.save(opcao);
		
		return opcao;
	}
	
	public Opcao buscar(Long id){
		
		return opcaoRepositorio.findOne(id);
	}
}
