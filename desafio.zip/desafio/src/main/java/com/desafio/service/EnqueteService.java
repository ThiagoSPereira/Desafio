package com.desafio.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.desafio.domain.Enquete;
import com.desafio.repositorio.OpcaoRepositorio;
import com.desafio.repositorio.EnqueteRepositorio;

@Service
public class EnqueteService {

	private EnqueteRepositorio questaoRepositorio;
	private OpcaoRepositorio opcaoRepositorio;
	
	@Autowired
	public EnqueteService(EnqueteRepositorio questaoRepositorio){
		this.questaoRepositorio = questaoRepositorio;
	}
	
	// Cadastro no banco de dados
	public Enquete cadastrar(Enquete questao){
		
		Enquete questaoCadas = questaoRepositorio.save(questao);
		
		return questaoCadas;		
	}
	
	// Busca a enquete no banco de dados
	public Enquete buscar(Long id){
		
		return questaoRepositorio.findOne(id);
	}
	
	// Busca uma lista de todas as enquetes
	public List<Enquete> listar(){
		
		List<Enquete> questoes = questaoRepositorio.findAll();
		
		return questoes;
	}
	

	
}
