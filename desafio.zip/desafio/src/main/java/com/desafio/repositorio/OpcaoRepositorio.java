package com.desafio.repositorio;

import org.springframework.data.jpa.repository.JpaRepository;

import com.desafio.domain.Opcao;

public interface OpcaoRepositorio extends JpaRepository<Opcao, Long>{

}
