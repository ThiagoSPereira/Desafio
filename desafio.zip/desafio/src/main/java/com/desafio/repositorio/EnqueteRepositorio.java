package com.desafio.repositorio;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.desafio.domain.Enquete;

@Repository
public interface EnqueteRepositorio extends JpaRepository<Enquete, Long>{
	
}
