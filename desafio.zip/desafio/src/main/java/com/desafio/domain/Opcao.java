package com.desafio.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@Entity
@JsonInclude(Include.NON_NULL)
public class Opcao {
	
	@GeneratedValue
	@Id
	private Long option_id;
	
	@Column(nullable = false)
	private String option_description;
	
	private Long qty;
	
	@ManyToOne
	private Enquete poll;

	public Long getOption_id() {
		return option_id;
	}

	public void setOption_id(Long option_id) {
		this.option_id = option_id;
	}

	public String getOption_description() {
		return option_description;
	}

	public void setOption_description(String option_description) {
		this.option_description = option_description;
	}

	public Long getQty() {
		return qty;
	}

	public void setQty(Long qty) {
		this.qty = qty;
	}

	@JsonIgnore
	public Enquete getPoll() {
		return poll;
	}

	public void setPoll(Enquete poll) {
		this.poll = poll;
	}
	

}
